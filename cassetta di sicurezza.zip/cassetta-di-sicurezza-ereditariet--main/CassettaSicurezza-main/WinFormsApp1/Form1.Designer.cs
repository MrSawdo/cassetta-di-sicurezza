﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn1 = new Button();
            btn2 = new Button();
            btn4 = new Button();
            btn3 = new Button();
            btn6 = new Button();
            btn5 = new Button();
            btn0 = new Button();
            btn9 = new Button();
            btn8 = new Button();
            btn7 = new Button();
            label1 = new Label();
            confermabtn = new Button();
            groupBox1 = new GroupBox();
            buttonClear = new Button();
            groupBox2 = new GroupBox();
            buttoneditPIN = new Button();
            buttonClose = new Button();
            buttonOpen = new Button();
            labelState = new Label();
            groupBox3 = new GroupBox();
            comboBoxKeyType = new ComboBox();
            label3 = new Label();
            label2 = new Label();
            textBoxType = new TextBox();
            comboBoxObj = new ComboBox();
            buttonRemove = new Button();
            buttonAdd = new Button();
            labelObject = new Label();
            label4 = new Label();
            label5 = new Label();
            labelValue = new Label();
            label6 = new Label();
            labelAssicurazione = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // btn1
            // 
            btn1.Location = new Point(19, 110);
            btn1.Margin = new Padding(4, 5, 4, 5);
            btn1.Name = "btn1";
            btn1.Size = new Size(66, 75);
            btn1.TabIndex = 0;
            btn1.Text = "1";
            btn1.UseVisualStyleBackColor = true;
            btn1.Click += btn1_Click;
            // 
            // btn2
            // 
            btn2.Location = new Point(93, 110);
            btn2.Margin = new Padding(4, 5, 4, 5);
            btn2.Name = "btn2";
            btn2.Size = new Size(66, 75);
            btn2.TabIndex = 1;
            btn2.Text = "2";
            btn2.UseVisualStyleBackColor = true;
            btn2.Click += btn2_Click;
            // 
            // btn4
            // 
            btn4.Location = new Point(19, 195);
            btn4.Margin = new Padding(4, 5, 4, 5);
            btn4.Name = "btn4";
            btn4.Size = new Size(66, 75);
            btn4.TabIndex = 3;
            btn4.Text = "4";
            btn4.UseVisualStyleBackColor = true;
            btn4.Click += btn4_Click;
            // 
            // btn3
            // 
            btn3.Location = new Point(167, 110);
            btn3.Margin = new Padding(4, 5, 4, 5);
            btn3.Name = "btn3";
            btn3.Size = new Size(66, 75);
            btn3.TabIndex = 2;
            btn3.Text = "3";
            btn3.UseVisualStyleBackColor = true;
            btn3.Click += btn3_Click;
            // 
            // btn6
            // 
            btn6.Location = new Point(167, 195);
            btn6.Margin = new Padding(4, 5, 4, 5);
            btn6.Name = "btn6";
            btn6.Size = new Size(66, 75);
            btn6.TabIndex = 5;
            btn6.Text = "6";
            btn6.UseVisualStyleBackColor = true;
            btn6.Click += btn6_Click;
            // 
            // btn5
            // 
            btn5.Location = new Point(93, 195);
            btn5.Margin = new Padding(4, 5, 4, 5);
            btn5.Name = "btn5";
            btn5.Size = new Size(66, 75);
            btn5.TabIndex = 4;
            btn5.Text = "5";
            btn5.UseVisualStyleBackColor = true;
            btn5.Click += btn5_Click;
            // 
            // btn0
            // 
            btn0.Location = new Point(93, 365);
            btn0.Margin = new Padding(4, 5, 4, 5);
            btn0.Name = "btn0";
            btn0.Size = new Size(66, 75);
            btn0.TabIndex = 10;
            btn0.Text = "0";
            btn0.UseVisualStyleBackColor = true;
            btn0.Click += btn0_Click;
            // 
            // btn9
            // 
            btn9.Location = new Point(167, 280);
            btn9.Margin = new Padding(4, 5, 4, 5);
            btn9.Name = "btn9";
            btn9.Size = new Size(66, 75);
            btn9.TabIndex = 8;
            btn9.Text = "9";
            btn9.UseVisualStyleBackColor = true;
            btn9.Click += btn9_Click;
            // 
            // btn8
            // 
            btn8.Location = new Point(93, 280);
            btn8.Margin = new Padding(4, 5, 4, 5);
            btn8.Name = "btn8";
            btn8.Size = new Size(66, 75);
            btn8.TabIndex = 7;
            btn8.Text = "8";
            btn8.UseVisualStyleBackColor = true;
            btn8.Click += btn8_Click;
            // 
            // btn7
            // 
            btn7.Location = new Point(19, 280);
            btn7.Margin = new Padding(4, 5, 4, 5);
            btn7.Name = "btn7";
            btn7.Size = new Size(66, 75);
            btn7.TabIndex = 6;
            btn7.Text = "7";
            btn7.UseVisualStyleBackColor = true;
            btn7.Click += btn7_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(93, 53);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(59, 25);
            label1.TabIndex = 11;
            label1.Text = "label1";
            // 
            // confermabtn
            // 
            confermabtn.Location = new Point(167, 365);
            confermabtn.Margin = new Padding(4, 5, 4, 5);
            confermabtn.Name = "confermabtn";
            confermabtn.Size = new Size(66, 75);
            confermabtn.TabIndex = 12;
            confermabtn.Text = "ok";
            confermabtn.UseVisualStyleBackColor = true;
            confermabtn.Click += confermabtn_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(confermabtn);
            groupBox1.Controls.Add(buttonClear);
            groupBox1.Controls.Add(btn0);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(btn9);
            groupBox1.Controls.Add(btn1);
            groupBox1.Controls.Add(btn8);
            groupBox1.Controls.Add(btn2);
            groupBox1.Controls.Add(btn7);
            groupBox1.Controls.Add(btn3);
            groupBox1.Controls.Add(btn6);
            groupBox1.Controls.Add(btn4);
            groupBox1.Controls.Add(btn5);
            groupBox1.Location = new Point(17, 20);
            groupBox1.Margin = new Padding(4, 5, 4, 5);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(4, 5, 4, 5);
            groupBox1.Size = new Size(286, 458);
            groupBox1.TabIndex = 13;
            groupBox1.TabStop = false;
            groupBox1.Text = "Tastierino";
            // 
            // buttonClear
            // 
            buttonClear.Location = new Point(19, 365);
            buttonClear.Margin = new Padding(4, 5, 4, 5);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(66, 75);
            buttonClear.TabIndex = 14;
            buttonClear.Text = "-";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += buttonClear_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(buttoneditPIN);
            groupBox2.Controls.Add(buttonClose);
            groupBox2.Controls.Add(buttonOpen);
            groupBox2.Location = new Point(357, 20);
            groupBox2.Margin = new Padding(4, 5, 4, 5);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(4, 5, 4, 5);
            groupBox2.Size = new Size(179, 185);
            groupBox2.TabIndex = 16;
            groupBox2.TabStop = false;
            groupBox2.Text = "Controlli Cassetta";
            // 
            // buttoneditPIN
            // 
            buttoneditPIN.Location = new Point(9, 133);
            buttoneditPIN.Margin = new Padding(4, 5, 4, 5);
            buttoneditPIN.Name = "buttoneditPIN";
            buttoneditPIN.Size = new Size(140, 38);
            buttoneditPIN.TabIndex = 2;
            buttoneditPIN.Text = "Modifica PIN";
            buttoneditPIN.UseVisualStyleBackColor = true;
            buttoneditPIN.Click += buttoneditPIN_Click;
            // 
            // buttonClose
            // 
            buttonClose.Location = new Point(9, 85);
            buttonClose.Margin = new Padding(4, 5, 4, 5);
            buttonClose.Name = "buttonClose";
            buttonClose.Size = new Size(140, 38);
            buttonClose.TabIndex = 1;
            buttonClose.Text = "Chiudi";
            buttonClose.UseVisualStyleBackColor = true;
            buttonClose.Click += buttonClose_Click;
            // 
            // buttonOpen
            // 
            buttonOpen.Location = new Point(9, 37);
            buttonOpen.Margin = new Padding(4, 5, 4, 5);
            buttonOpen.Name = "buttonOpen";
            buttonOpen.Size = new Size(140, 38);
            buttonOpen.TabIndex = 0;
            buttonOpen.Text = "Apri";
            buttonOpen.UseVisualStyleBackColor = true;
            buttonOpen.Click += buttonOpen_Click;
            // 
            // labelState
            // 
            labelState.AutoSize = true;
            labelState.Font = new Font("幼圆", 48F, FontStyle.Bold, GraphicsUnit.Point);
            labelState.Location = new Point(591, 29);
            labelState.Margin = new Padding(4, 0, 4, 0);
            labelState.Name = "labelState";
            labelState.Size = new Size(189, 97);
            labelState.TabIndex = 17;
            labelState.Text = "---";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(comboBoxKeyType);
            groupBox3.Controls.Add(label3);
            groupBox3.Controls.Add(label2);
            groupBox3.Controls.Add(textBoxType);
            groupBox3.Controls.Add(comboBoxObj);
            groupBox3.Controls.Add(buttonRemove);
            groupBox3.Controls.Add(buttonAdd);
            groupBox3.Location = new Point(357, 240);
            groupBox3.Margin = new Padding(4, 5, 4, 5);
            groupBox3.Name = "groupBox3";
            groupBox3.Padding = new Padding(4, 5, 4, 5);
            groupBox3.Size = new Size(503, 220);
            groupBox3.TabIndex = 17;
            groupBox3.TabStop = false;
            groupBox3.Text = "Gestione contenuto";
            // 
            // comboBoxKeyType
            // 
            comboBoxKeyType.FormattingEnabled = true;
            comboBoxKeyType.Items.AddRange(new object[] { "Elettronica", "Fisica" });
            comboBoxKeyType.Location = new Point(291, 48);
            comboBoxKeyType.Margin = new Padding(4, 5, 4, 5);
            comboBoxKeyType.Name = "comboBoxKeyType";
            comboBoxKeyType.Size = new Size(193, 33);
            comboBoxKeyType.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(9, 92);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(80, 25);
            label3.TabIndex = 5;
            label3.Text = "Oggetto";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(291, 92);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(47, 25);
            label2.TabIndex = 4;
            label2.Text = "Tipo";
            // 
            // textBoxType
            // 
            textBoxType.Location = new Point(291, 48);
            textBoxType.Margin = new Padding(4, 5, 4, 5);
            textBoxType.Name = "textBoxType";
            textBoxType.Size = new Size(193, 31);
            textBoxType.TabIndex = 3;
            // 
            // comboBoxObj
            // 
            comboBoxObj.FormattingEnabled = true;
            comboBoxObj.Items.AddRange(new object[] { "Generico", "Gioiello", "Documento", "Chiave" });
            comboBoxObj.Location = new Point(9, 47);
            comboBoxObj.Margin = new Padding(4, 5, 4, 5);
            comboBoxObj.Name = "comboBoxObj";
            comboBoxObj.Size = new Size(187, 33);
            comboBoxObj.TabIndex = 2;
            comboBoxObj.SelectedIndexChanged += comboBoxObj_SelectedIndexChanged;
            // 
            // buttonRemove
            // 
            buttonRemove.Location = new Point(9, 172);
            buttonRemove.Margin = new Padding(4, 5, 4, 5);
            buttonRemove.Name = "buttonRemove";
            buttonRemove.Size = new Size(140, 38);
            buttonRemove.TabIndex = 1;
            buttonRemove.Text = "Rimuovi";
            buttonRemove.UseVisualStyleBackColor = true;
            buttonRemove.Click += buttonRemove_Click;
            // 
            // buttonAdd
            // 
            buttonAdd.Location = new Point(346, 172);
            buttonAdd.Margin = new Padding(4, 5, 4, 5);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(140, 38);
            buttonAdd.TabIndex = 0;
            buttonAdd.Text = "Aggiungi";
            buttonAdd.UseVisualStyleBackColor = true;
            buttonAdd.Click += buttonAdd_Click;
            // 
            // labelObject
            // 
            labelObject.AutoSize = true;
            labelObject.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            labelObject.Location = new Point(1037, 73);
            labelObject.Margin = new Padding(4, 0, 4, 0);
            labelObject.Name = "labelObject";
            labelObject.Size = new Size(33, 25);
            labelObject.TabIndex = 18;
            labelObject.Text = "---";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(872, 73);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(114, 25);
            label4.TabIndex = 19;
            label4.Text = "Stato interno";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(872, 133);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(86, 25);
            label5.TabIndex = 21;
            label5.Text = "Valore (€)";
            // 
            // labelValue
            // 
            labelValue.AutoSize = true;
            labelValue.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            labelValue.Location = new Point(1037, 133);
            labelValue.Margin = new Padding(4, 0, 4, 0);
            labelValue.Name = "labelValue";
            labelValue.Size = new Size(33, 25);
            labelValue.TabIndex = 20;
            labelValue.Text = "---";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(872, 183);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(144, 25);
            label6.TabIndex = 23;
            label6.Text = "Assicurazione (€)";
            // 
            // labelAssicurazione
            // 
            labelAssicurazione.AutoSize = true;
            labelAssicurazione.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            labelAssicurazione.Location = new Point(1037, 183);
            labelAssicurazione.Margin = new Padding(4, 0, 4, 0);
            labelAssicurazione.Name = "labelAssicurazione";
            labelAssicurazione.Size = new Size(33, 25);
            labelAssicurazione.TabIndex = 22;
            labelAssicurazione.Text = "---";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1326, 630);
            Controls.Add(label6);
            Controls.Add(labelAssicurazione);
            Controls.Add(label5);
            Controls.Add(labelValue);
            Controls.Add(label4);
            Controls.Add(labelObject);
            Controls.Add(groupBox3);
            Controls.Add(labelState);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "cassettaDiSicurezza";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn1;
        private Button btn2;
        private Button btn4;
        private Button btn3;
        private Button btn6;
        private Button btn5;
        private Button btn0;
        private Button btn9;
        private Button btn8;
        private Button btn7;
        private Label label1;
        private Button confermabtn;
        private GroupBox groupBox1;
        private Button buttonClear;
        private GroupBox groupBox2;
        private Button buttonClose;
        private Button buttonOpen;
        private Button buttoneditPIN;
        private Label labelState;
        private GroupBox groupBox3;
        private TextBox textBoxType;
        private ComboBox comboBoxObj;
        private Button buttonRemove;
        private Button buttonAdd;
        private Label labelObject;
        private ComboBox comboBoxKeyType;
        private Label label3;
        private Label label2;
        private Label label4;
        private Label label5;
        private Label labelValue;
        private Label label6;
        private Label labelAssicurazione;
    }
}
